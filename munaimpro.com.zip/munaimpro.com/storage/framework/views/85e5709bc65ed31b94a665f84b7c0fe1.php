
<div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Project Details</h5>
            </div>
            <div class="modal-body">
                <form id="updatePortfolioForm">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Title</label>
                            <input class="form-control" type="text" id="updateProjectTitle">
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Project Type</label>
                            <input class="form-control" type="text" id="updateProjectType">
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Category</label>
                            <select class="form-control" type="text" id="updateServiceId">
                                
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Starting Date</label>
                            <input class="form-control" type="date" id="updateProjectStartingDate">
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Ending Date</label>
                            <input class="form-control" type="date" id="updateProjectEndingDate" onchange="toggleUpdateProjectStatus()">
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>URL</label>
                            <input class="form-control" type="url" id="updateProjectUrl">
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Core Technologies</label>
                            <input class="form-control" type="text" id="updateProjectTechnology">
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Description</label>
                            <textarea class="contentDetails" id="updateProjectDescription"></textarea>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Thumbnail</label>
                            <div class="image-upload">
                                <input class="form-control" type="file" id="updateProjectThumbnail" oninput="updateProjectThumbnailPreview.src=window.URL.createObjectURL(this.files[0])">
                                <div class="image-uploads">
                                    <img src="<?php echo e(asset('assets/img/icons/upload.svg')); ?>" alt="img">
                                    <h4>Drag and drop a file to upload</h4>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="product-list">
                        <ul class="row">
                            <li class="ps-0">
                                <div class="productviewset">
                                    <div class="productviewsimg">
                                        <img src="<?php echo e(asset('assets/img/customer/profile2.jpg')); ?>" alt="img" id="updateProjectThumbnailPreview">
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>UI Image</label>
                            <div class="image-upload">
                                <input class="form-control" type="file" id="updateProjectUiImage" multiple>
                                <div class="image-uploads">
                                    <img src="<?php echo e(asset('assets/img/icons/upload.svg')); ?>" alt="img">
                                    <h4>Drag and drop a file to upload</h4>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Image Preview Container -->
                    <div class="col-12">
                        <div class="product-list">
                            <ul class="row" id="imagePreviewContainer">

                            </ul>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Portfolio Visibility</label>
                        <input type="text" class="form-control" id="viewPortfolioVisibility">
                    </div>

                    <h6 class="text-center mt-5 mb-1">Client Feedback</h6>

                    <div class="product-list">
                        <ul class="row justify-content-center">
                            <li class="p-0">
                                <div class="productviewset p-0">
                                    <div class="productviewsimg rounded-circle overflow-hidden m-auto" style="max-width: 120px; height: 120px;">
                                        <img class="h-100" src="<?php echo e(asset('assets/img/customer/profile2.jpg')); ?>" alt="img" id="clientImage">
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
    
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" class="form-control" id="clientFirstName">
                        </div>
                    </div>
    
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" class="form-control" id="clientLastName">
                        </div>
                    </div>
    
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Designation</label>
                            <input type="text" class="form-control" id="clientDesignation">
                        </div>
                    </div>
    
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Feedback</label>
                            <textarea class="form-control" id="clientFeedback"></textarea>
                        </div>
                    </div>
    
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label>Date</label>
                            <input type="text" class="form-control" id="clientFeedbackDate">
                        </div>
                    </div>

                    <input type="text" id="portfolioInfoId">
                </form>
            </div>
            <div class="modal-footer justify-content-end">
                <button type="button" class="btn btn-submit" data-bs-dismiss="modal">Ok</button>
                <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>






<script>

    // Function for retrive post details

    // async function retrivePortfolioInfoById(portfolio_info_id){

    //     try{
    //         // Assigning id to hidden field
    //         document.getElementById('portfolioInfoId').value = portfolio_info_id;

    //         // Pssing id to controller and getting response
    //         showLoader();
    //         let response = await axios.post('../retrivePortfolioInfoById', {portfolio_info_id:portfolio_info_id});
    //         hideLoader();

    //         if(response.data['status'] === 'success'){
    //             // Getting base URL of the system
    //             let baseUrl = "<?php echo e(url('/')); ?>";
                
    //             // Generating full path for the project thumbnail
    //             let projectThumbnailFullPath = baseUrl + '/storage/portfolio/thumbnails/' + response.data.data['project_thumbnail'];
            
    //             // Assigning retrived values
    //             $('#updateProjectTitle').val(response.data.data['project_title']);
    //             $('#updateProjectType').val(response.data.data['project_type']);
    //             $('#updateProjectStartingDate').val(response.data.data['project_starting_date']);
    //             $('#updateProjectEndingDate').val(response.data.data['project_ending_date']);
    //             $('#updateProjectThumbnailPreview')[0].src = projectThumbnailFullPath;
    //             getUiImagePreview(JSON.parse(response.data.data['project_ui_image']));
    //             $('#updateServiceId').val(response.data.data['service_id']);
    //             tinymce.get('updateProjectDescription').setContent(response.data.data['project_description']);
    //             $('#updateProjectUrl').val(response.data.data['project_url']);
    //             $('#updateProjectTechnology').val(response.data.data['core_technology']);
    //             $('#updateProjectStatus').val(response.data.data['project_status']);
    //         } else{
    //             displayToast('error', response.data['message']);
    //         }
    //     } catch(e){
    //         console.error('Something went wrong', e);
    //     }
    // }

</script>

<?php /**PATH C:\xampp\htdocs\Personal_Portfolio\munaimpro.com\resources\views/admin/components/portfolio/portfolio_view.blade.php ENDPATH**/ ?>