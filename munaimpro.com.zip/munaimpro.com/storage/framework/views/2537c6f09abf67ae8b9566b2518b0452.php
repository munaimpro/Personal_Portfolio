
</div>
</div>
<div class="login-img">
    <img src="<?php echo e(asset('assets/img/login.jpg')); ?>" alt="img">
</div>
</div>
</div>
</div>



<script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/axios.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/feather.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Personal_Portfolio\munaimpro.com\resources\views/admin/components/signin/signin_footer.blade.php ENDPATH**/ ?>