<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="utf-8">

    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    
    
    <title><?php echo e(ucwords($routeName)); ?> - Admin - <?php echo e(ucwords('munaimpro')); ?></title>

    
    

    
    

    
    <meta name="author" content="Munaim Khan">

    
    

    
    

    
    

    
    

    
    

    
    <meta http-equiv="Content-Language" content="en">

    
    <meta name="application-name" content="Munaim">

    
    <meta name="theme-color" content="#ffffff">

    
    <meta name="google-site-verification" content="your_verification_token_here">

    
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">

    
    <meta name="referrer" content="no-referrer-when-downgrade">

    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.jpg')); ?>">

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
    
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/all.min.css')); ?>">
    
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/js/axios.min.js')); ?>"></script>

    
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-ajax/dist/leaflet.ajax.min.js"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>

    
    <script>
        function showLoader(){
            $('#global-loader').removeClass('d-none');
        }

        function hideLoader(){
            $('#global-loader').addClass('d-none');
        }
    </script>

    
    <style>
        #map {
            height: 500px;
            width: 100%;
        }
    </style>
</head>
<body>
    
    <div id="global-loader">
        <div class="whirly-loader"> </div>
    </div>
    

    
    <div class="main-wrapper">
        <?php if($routeName != '{token}'): ?>
            
            <?php echo $__env->make('admin.layouts.header.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

            
            <?php echo $__env->make('admin.layouts.sidebar.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

            
            <div class="page-wrapper">
                <div class="content">

                    <?php echo $__env->yieldContent('content'); ?>
                
                </div>
            </div>
            
        <?php else: ?>
            
            <div class="page-wrapper" style="margin: auto 100px">
                <div class="content">

                    <?php echo $__env->yieldContent('content'); ?>
                
                </div>
            </div>
            
        <?php endif; ?>
    </div>
    






<script src="<?php echo e(asset('assets/js/feather.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>
    

<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>





<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/plugins/apexchart/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/apexchart/chart-data.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/tinymce/tinymce.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

<script>
    // Function for toast message common features
    function displayToast(icon, title){
        Swal.fire({
            toast: true,
            position: 'top-end',
            icon: icon,
            iconColor: 'white',
            title: title,
            showConfirmButton: false,
            timer: 3000,
            customClass: {
                popup: 'colored-toast'
            }
        });
    }
</script>


</body>
</html><?php /**PATH C:\xampp\htdocs\Personal_Portfolio\munaimpro.com\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>