
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li>
                    <a <?php if($routeName === 'dashboard'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/dashboard')); ?>"><img src="<?php echo e(asset('assets/img/icons/dashboard.svg')); ?>" alt="img"><span> Dashboard</span> </a>
                </li>
                
                <li class="submenu">
                    <a href="javascript:void(0);"><img src="<?php echo e(asset('assets/img/icons/product.svg')); ?>" alt="img"><span> Website Details</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a <?php if($routeName === 'seoproperty'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/seoproperty')); ?>">Logo & SEO Information</a></li>
                        <li><a <?php if($routeName === 'visitorinfo'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/visitorinfo')); ?>">Visitor Information</a></li>
                    </ul>
                </li>
                
                <li class="submenu">
                    <a href="javascript:void(0);"><img src="<?php echo e(asset('assets/img/icons/sales1.svg')); ?>" alt="img"><span> About</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a <?php if($routeName === 'about'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/about')); ?>">Basic Information</a></li>
                        <li><a <?php if($routeName === 'education'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/education')); ?>">Education</a></li>
                        <li><a <?php if($routeName === 'skill'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/skill')); ?>">Skills</a></li>
                        <li><a <?php if($routeName === 'award'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/award')); ?>">Awards</a></li>
                        <li><a <?php if($routeName === 'experience'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/experience')); ?>">Experience</a></li>
                        <li><a <?php if($routeName === 'interest'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/interest')); ?>">Interest</a></li>
                        <li><a <?php if($routeName === 'social_media'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/social_media')); ?>">Social Media</a></li>
                    </ul>
                </li>
                
                <li>
                    <a <?php if($routeName === 'service'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/service')); ?>"><i data-feather="file"></i><span> Service</span> </a>
                </li>
                
                <li>
                    <a <?php if($routeName === 'portfolio'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/portfolio')); ?>"><i data-feather="file"></i><span> Portfolio</span> </a>
                </li>
                
                <li>
                    <a <?php if($routeName === 'pricing'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/pricing')); ?>"><i data-feather="file"></i><span> Pricing</span> </a>
                </li>
                
                <li>
                    <a <?php if($routeName === 'message'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/message')); ?>"><i data-feather="file"></i><span> Message</span> </a>
                </li>
                
                <li>
                    <a <?php if($routeName === 'client_feedback'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/client_feedback')); ?>"><i data-feather="file"></i><span> Client Feedback</span> </a>
                </li>
                
                <li class="submenu">
                    <a href="javascript:void(0);"><img src="<?php echo e(asset('assets/img/icons/expense1.svg')); ?>" alt="img"><span> Post</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a <?php if($routeName === 'post'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/post')); ?>">All Post</a></li>
                        <li><a <?php if($routeName === 'category'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/category')); ?>">Category List</a></li>
                    </ul>
                </li>
                
                <li>
                    <a <?php if($routeName === 'user'): ?> class="active" <?php endif; ?> href="<?php echo e(url('Admin/user')); ?>"><img src="<?php echo e(asset('assets/img/icons/users1.svg')); ?>" alt="img"><span> Users</span> </a>
                </li>

                <li class="submenu">
                    <a href="javascript:void(0);"><img src="<?php echo e(asset('assets/img/icons/settings.svg')); ?>" alt="img"><span> Settings</span> <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a href="generalsettings.html">General Settings</a></li>
                        <li><a href="emailsettings.html">Email Settings</a></li>
                        <li><a href="paymentsettings.html">Payment Settings</a></li>
                        <li><a href="currencysettings.html">Currency Settings</a></li>
                        <li><a href="grouppermissions.html">Group Permissions</a></li>
                        <li><a href="taxrates.html">Tax Rates</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Personal_Portfolio\munaimpro.com\resources\views/admin/layouts/sidebar/admin_sidebar.blade.php ENDPATH**/ ?>