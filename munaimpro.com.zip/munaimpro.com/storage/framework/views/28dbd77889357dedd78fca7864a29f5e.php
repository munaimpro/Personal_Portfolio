
<section class="breadcumb_wrapper">
    <div class="container-fluid vertical_MK25_w_space">
        <div class="row">
            <div class="col-12 text-center breadcrumb_bg">
                <div class="breadcrumb_MK25_title">
                    <h2 class="text-capitalize section_MK25_first_title">Pricing</h2>
                    <div class="breadcrumb_MK25_links">
                        <a class="external_MK25_section_link fw-bold" href="index.html">Home</a>
                        <span class="ms-1 fw-bold">Pricing</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\Personal_Portfolio\munaimpro.com\resources\views/website/components/pricing/breadcrumb.blade.php ENDPATH**/ ?>