
<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('website.components.home.banner'); ?>
    <?php $__env->startComponent('website.components.home.about'); ?>
    <?php $__env->startComponent('website.components.home.skills'); ?>
    <?php $__env->startComponent('website.components.home.service'); ?>
    <?php $__env->startComponent('website.components.home.portfolio'); ?>
    <?php $__env->startComponent('website.components.home.testimonial'); ?>
    <?php $__env->startComponent('website.components.home.blog'); ?>
    <?php $__env->startComponent('website.components.home.contact'); ?>
<?php $__env->stopSection(); ?>

    

    
    
    

    
    

    



    


    

    

    
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Personal_Portfolio\munaimpro.com\resources\views/website/pages/home.blade.php ENDPATH**/ ?>