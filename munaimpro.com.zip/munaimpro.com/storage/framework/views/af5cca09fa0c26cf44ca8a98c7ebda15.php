
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">

    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <title><?php echo e(ucwords($routeName)); ?> - Admin - <?php echo e(ucwords('munaimpro')); ?></title>

    
    

    
    

    
    

    
    

    
    

    
    

    
    

    
    <meta http-equiv="Content-Language" content="en">

    
    <meta name="referrer" content="no-referrer-when-downgrade">

    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.jpg')); ?>">

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/all.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    
    <script>
        function showLoader(){
            $('#global-loader').removeClass('d-none');
        }

        function hideLoader(){
            $('#global-loader').addClass('d-none');
        }
    </script>
</head>

<body class="account-page">
    
    <div id="global-loader" class="d-none">
        <div class="whirly-loader"> </div>
    </div>
    

<div class="main-wrapper">
    <div class="account-content">
        <div class="login-wrapper">
            <div class="login-content">
                <div class="login-userset">
                    <div class="login-logo">
                        <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="img">
                    </div>
                    <div class="login-userheading">
                        <h3>Sign In</h3>
                        <h4>Please login to your account</h4>
                    </div>
<?php /**PATH C:\xampp\htdocs\Personal_Portfolio\munaimpro.com\resources\views/admin/components/signin/signin_header.blade.php ENDPATH**/ ?>