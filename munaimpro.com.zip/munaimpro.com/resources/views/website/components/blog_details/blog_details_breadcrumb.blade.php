{{-- Breadcrumb section start --}}
<section class="breadcumb_wrapper">
    <div class="container-fluid vertical_MK25_w_space">
        <div class="row">
            <div class="col-12 text-center breadcrumb_bg breadcrumb_MK25_blog">
                <div class="breadcrumb_MK25_title">
                    <h3 class="text-uppercase section_MK25_first_title" id="websiteBlogHeading"></h3>
                    <div class="breadcrumb_MK25_links">
                        <a class="external_MK25_section_link" href="" id="websiteBlogUser"></a>
                        <span class="ms-1" id="websiteBlogPublishDate"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
{{-- Breadcrumb section end --}}