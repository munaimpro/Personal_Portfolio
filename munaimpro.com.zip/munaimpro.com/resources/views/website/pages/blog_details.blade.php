@extends('website.layouts.app')
@section('component')
    @include('website.components.blog_details.blog_details_breadcrumb')
    @include('website.components.blog_details.blog_details_content')
@endsection


    
