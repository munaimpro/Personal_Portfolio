@extends('website.layouts.app')
@section('component')
    @include('website.components.contact.contact_breadcrumb')
    @include('website.components.contact.contact_form')
@endsection