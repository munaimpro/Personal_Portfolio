@extends('website.layouts.app')
@section('component')
    @include('website.components.pricing.pricing_breadcrumb')
    @include('website.components.pricing.pricing_list')
    @include('website.components.pricing.pricing_contact')
@endsection