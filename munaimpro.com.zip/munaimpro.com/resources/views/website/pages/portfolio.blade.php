@extends('website.layouts.app')
@section('component')
    @include('website.components.portfolio.portfolio_breadcrumb')
    @include('website.components.portfolio.portfolio_list')
@endsection