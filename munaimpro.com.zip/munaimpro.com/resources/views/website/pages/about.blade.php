@extends('website.layouts.app')
@section('component')
    @include('website.components.about.about_breadcrumb')
    @include('website.components.about.about_education_skill')
    @include('website.components.about.about_interest')
    @include('website.components.about.about_call_to_action')
    @include('website.components.about.about_contact')
@endsection