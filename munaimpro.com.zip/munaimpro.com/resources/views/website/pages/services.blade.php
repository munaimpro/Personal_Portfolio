@extends('website.layouts.app')
@section('component')
    @include('website.components.services.service_breadcrumb')
    @include('website.components.services.service_list')
    @include('website.components.services.service_call_to_action')
@endsection