@extends('website.layouts.app')
@section('component')
    @include('website.components.blog.blog_breadcrumb')
    @include('website.components.blog.blog_list')
@endsection