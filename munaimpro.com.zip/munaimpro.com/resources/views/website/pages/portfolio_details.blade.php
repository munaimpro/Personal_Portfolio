@extends('website.layouts.app')
@section('component')
    @include('website.components.portfolio_details.portfolio_details_breadcrumb')
    @include('website.components.portfolio_details.portfolio_content')
@endsection