{{-- Send OTP footer start --}}
</div>
</div>
<div class="login-img">
<img src="{{ asset('assets/img/login.jpg') }}" alt="img">
</div>
</div>
</div>
</div>



{{-- jQuery JS --}}
<script src="{{ asset('assets/js/jquery-3.6.0.min.js') }}"></script>

{{-- Axios JS --}}
<script src="{{ asset('assets/js/axios.min.js') }}"></script>

{{-- Feather JS --}}
<script src="{{ asset('assets/js/feather.min.js') }}"></script>

{{-- Bootstrap JS --}}
<script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>

{{-- Custom JS --}}
<script src="{{ asset('assets/js/script.js') }}"></script>
</body>
</html>
{{-- Footer end --}}