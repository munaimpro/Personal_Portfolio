@extends('admin.layouts.app')
@section('content')
    @include('admin.components.profile.change_password')
    @include('admin.components.profile.profile_form')
@endsection