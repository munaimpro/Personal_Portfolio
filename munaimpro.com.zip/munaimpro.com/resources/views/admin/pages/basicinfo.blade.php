@extends('admin.layouts.app')
@section('content')
    @include('admin.components.basicinfo.basicinfo_form')
@endsection