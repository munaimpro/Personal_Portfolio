@include('admin.components.sendotp.sendotp_header')
@include('admin.components.sendotp.sendotp_form')
@include('admin.components.sendotp.sendotp_footer')