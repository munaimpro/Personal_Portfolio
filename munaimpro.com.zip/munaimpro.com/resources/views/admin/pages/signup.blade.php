@include('admin.components.signup.signup_header')
@include('admin.components.signup.signup_form')
@include('admin.components.signup.signup_footer')