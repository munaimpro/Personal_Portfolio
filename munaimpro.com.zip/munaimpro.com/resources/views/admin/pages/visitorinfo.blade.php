@extends('admin.layouts.app')
@section('content')
    @include('admin.components.visitorinfo.visitorinfo_view')
    @include('admin.components.visitorinfo.visitorinfo_list')
@endsection